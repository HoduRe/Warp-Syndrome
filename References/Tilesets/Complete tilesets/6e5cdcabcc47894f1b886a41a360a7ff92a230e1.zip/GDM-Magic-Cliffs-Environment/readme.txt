Artwork created by Luis Zuno (@ansimuz)

Thank you for downloading my Free Magic Cliffs Tile Set & Background

Contents

PNG Folder
Contains all the layers ready to use in PNG Format

PREVIEWS
Flattened HD Res example PNG files

PSD
Working Photoshop format files for editing

Get more like these at: https://www.patreon.com/ansimuz

