Living Tissue Platform Tile Set and Background

The downloadable file contains everything you need to start working right away on your project. I have included the PSD and the transparent PNG file format.

- Contents

-- PNG Folder: Contains the ready to use 

-- PSD Folder: Contains the Working PSD file in case you need to modify them.

Thanks Again

Visit my site for more free resources at ansimuz.com